package com.example.mylogin_191

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
